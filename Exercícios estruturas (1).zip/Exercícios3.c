#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <locale.h>

//3. Fa�a um programa que leia dez n�meros inteiros e calcule a diferen�a entre o maior e o menor n�mero do conjunto.

int main (void) {
	
	int i, maior = 5, menor = 2, calc;
		
	for(i = 1; i <= 1; i++){
		
		calc = maior - menor;
		printf("%i", calc);
	}

	return 0;
}
